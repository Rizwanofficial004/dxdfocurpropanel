import React, { createContext, useContext, useState } from 'react';

const translations = {
  en: {
    // Common
    home: 'Home',
    dashboard: 'Dashboard',
    liveTracking: 'Live Tracking',
    quickView: 'Quick View',
    reports: 'Reports',
    site: 'Site',
    taskManagement: 'Task Management',
    attendance: 'Attendance',
    employees: 'Employees',
    teams: 'Teams',
    settings: 'Settings',
    search: 'Search',
    hello: 'Hello',
    
    // Login
    welcome: 'Welcome Back',
    subtitle: 'Sign in to your account to continue',
    email: 'Email Address',
    password: 'Password',
    remember: 'Remember me',
    forgot: 'Forgot password?',
    signIn: 'Sign In',
    signingIn: 'Signing in...',
    error: 'Invalid email or password. Try admin@example.com / password',
    loginFailed: 'Login failed. Please try again.',
    enterEmail: 'Enter your email',
    enterPassword: 'Enter your password',
    
    // Header
    searchHere: 'Search here...',
    notifications: 'Notifications',
    viewProfile: 'View Profile',
    accountSettings: 'Account Settings',
    helpSupport: 'Help & Support',
    signOut: 'Sign Out',
    active: 'Active',
    
    // Dashboard Cards
    totalEmployee: 'Total Employee',
    onLeaveEmployee: 'On Leave Employee',
    totalProject: 'Total Project',
    completeProject: 'Complete Project',
    totalClient: 'Total Client',
    totalRevenue: 'Total Revenue',
    totalJobs: 'Total Jobs',
    totalTicket: 'Total Ticket',
    thanLastYear: 'Than Last Year',
    thanLastMonth: 'Than Last Month',
    
    // Live Tracking
    realTimeActivityStream: 'Real Time Activity Stream',
    totalActive: 'Total Active',
    online: 'Online',
    idle: 'Idle',
    offline: 'Offline',
    totalHours: 'Total Hours',
    allEmployees: 'All Employees',
    allDepartments: 'All Departments',
    allStatus: 'All Status',
    development: 'Development',
    design: 'Design',
    marketing: 'Marketing',
    today: 'Today',
    yesterday: 'Yesterday',
    thisWeek: 'This Week',
    thisMonth: 'This Month',
    customRange: 'Custom Range',
    searchEmployeeName: 'Search employee name...',
    advancedFilter: 'Advanced Filter',
    export: 'Export',
    loadMoreScreenshots: 'Load More Screenshots',
    previous: 'Previous',
    next: 'Next',
    
    // Quick View
    status: 'Status',
    employeeName: 'Employee Name',
    loggedTime: 'Logged Time',
    activeTime: 'Active Time',
    productive: 'Productive',
    distraction: 'Distraction',
    neutral: 'Neutral',
    meeting: 'Meeting',
    break: 'Break',
    selectDate: 'Select Date',
    showing: 'Showing',
    of: 'of',
    entries: 'entries',
    show: 'Show',
    
    // Sidebar
    main: 'Main',
    management: 'Management',
    system: 'System',
    
    // Announcements
    recentAnnouncements: 'Recent Announcements',
    title: 'Title',
    type: 'Type',
    date: 'Date',
    author: 'Author',
    description: 'Description',
    urgent: 'Urgent',
    important: 'Important',
    info: 'Info',
    
    // Activity Stream
    recentActivity: 'Recent Activity',
    newUserRegistered: 'New user registered',
    reportGenerated: 'Report generated',
    taskCompleted: 'Task completed',
    documentUpdated: 'Document updated',
    minutesAgo: 'minutes ago',
    hourAgo: 'hour ago',
    hoursAgo: 'hours ago',
    dayAgo: 'day ago',
    
    // Pagination
    page: 'Page',
    itemsOnThisPage: 'items on this page',
  },
  
  tr: {
    // Common
    home: 'Ana Sayfa',
    dashboard: 'Kontrol Paneli',
    liveTracking: 'Canlı İzleme',
    quickView: 'Hızlı Görünüm',
    reports: 'Raporlar',
    site: 'Site',
    taskManagement: 'Görev Yönetimi',
    attendance: 'Devam',
    employees: 'Çalışanlar',
    teams: 'Takımlar',
    settings: 'Ayarlar',
    search: 'Ara',
    hello: 'Merhaba',
    
    // Login
    welcome: 'Tekrar Hoş Geldiniz',
    subtitle: 'Devam etmek için hesabınıza giriş yapın',
    email: 'E-posta Adresi',
    password: 'Şifre',
    remember: 'Beni hatırla',
    forgot: 'Şifrenizi mi unuttunuz?',
    signIn: 'Giriş Yap',
    signingIn: 'Giriş yapılıyor...',
    error: 'Geçersiz e-posta veya şifre. admin@example.com / password deneyin',
    loginFailed: 'Giriş başarısız. Lütfen tekrar deneyin.',
    enterEmail: 'E-posta adresinizi girin',
    enterPassword: 'Şifrenizi girin',
    
    // Header
    searchHere: 'Burada ara...',
    notifications: 'Bildirimler',
    viewProfile: 'Profili Görüntüle',
    accountSettings: 'Hesap Ayarları',
    helpSupport: 'Yardım ve Destek',
    signOut: 'Çıkış Yap',
    active: 'Aktif',
    
    // Dashboard Cards
    totalEmployee: 'Toplam Çalışan',
    onLeaveEmployee: 'İzinli Çalışan',
    totalProject: 'Toplam Proje',
    completeProject: 'Tamamlanan Proje',
    totalClient: 'Toplam Müşteri',
    totalRevenue: 'Toplam Gelir',
    totalJobs: 'Toplam İş',
    totalTicket: 'Toplam Bilet',
    thanLastYear: 'Geçen Yıldan',
    thanLastMonth: 'Geçen Aydan',
    
    // Live Tracking
    realTimeActivityStream: 'Gerçek Zamanlı Aktivite Akışı',
    totalActive: 'Toplam Aktif',
    online: 'Çevrimiçi',
    idle: 'Beklemede',
    offline: 'Çevrimdışı',
    totalHours: 'Toplam Saat',
    allEmployees: 'Tüm Çalışanlar',
    allDepartments: 'Tüm Departmanlar',
    allStatus: 'Tüm Durumlar',
    development: 'Geliştirme',
    design: 'Tasarım',
    marketing: 'Pazarlama',
    today: 'Bugün',
    yesterday: 'Dün',
    thisWeek: 'Bu Hafta',
    thisMonth: 'Bu Ay',
    customRange: 'Özel Aralık',
    searchEmployeeName: 'Çalışan adı ara...',
    advancedFilter: 'Gelişmiş Filtre',
    export: 'Dışa Aktar',
    loadMoreScreenshots: 'Daha Fazla Ekran Görüntüsü Yükle',
    previous: 'Önceki',
    next: 'Sonraki',
    
    // Quick View
    status: 'Durum',
    employeeName: 'Çalışan Adı',
    loggedTime: 'Giriş Saati',
    activeTime: 'Aktif Süre',
    productive: 'Üretken',
    distraction: 'Dikkat Dağıtıcı',
    neutral: 'Nötr',
    meeting: 'Toplantı',
    break: 'Mola',
    selectDate: 'Tarih Seç',
    showing: 'Gösteriliyor',
    of: '/',
    entries: 'kayıt',
    show: 'Göster',
    
    // Sidebar
    main: 'Ana',
    management: 'Yönetim',
    system: 'Sistem',
    
    // Announcements
    recentAnnouncements: 'Son Duyurular',
    title: 'Başlık',
    type: 'Tür',
    date: 'Tarih',
    author: 'Yazar',
    description: 'Açıklama',
    urgent: 'Acil',
    important: 'Önemli',
    info: 'Bilgi',
    
    // Activity Stream
    recentActivity: 'Son Aktiviteler',
    newUserRegistered: 'Yeni kullanıcı kaydedildi',
    reportGenerated: 'Rapor oluşturuldu',
    taskCompleted: 'Görev tamamlandı',
    documentUpdated: 'Belge güncellendi',
    minutesAgo: 'dakika önce',
    hourAgo: 'saat önce',
    hoursAgo: 'saat önce',
    dayAgo: 'gün önce',
    
    // Pagination
    page: 'Sayfa',
    itemsOnThisPage: 'bu sayfadaki öğe',
  }
};

const LanguageContext = createContext();

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState('en');

  const t = (key) => {
    return translations[language][key] || key;
  };

  const value = {
    language,
    setLanguage,
    t,
    translations: translations[language]
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};
